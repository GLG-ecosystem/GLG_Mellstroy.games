
self.addEventListener('install', (e)=>{
  e.waitUntil(caches.open('mell-pwa-v1').then(c=>c.addAll([
    './','./index.html','./styles.css','./app.js','./manifest.webmanifest'
  ])));
});
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return response || fetch(event.request);
    })
  );
});
