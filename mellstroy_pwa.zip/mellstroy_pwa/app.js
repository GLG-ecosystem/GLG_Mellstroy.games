
const routes = {
  home: renderHome,
  bonus: renderBonus,
  challenge: renderChallenge,
  profile: renderProfile,
};

const view = document.getElementById('view');
document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => navigate(btn.dataset.route));
});

function navigate(route='home'){
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active', b.dataset.route===route));
  const render = routes[route] || renderHome;
  view.innerHTML = '';
  render();
  history.replaceState(null,'','#/'+route);
}

function renderHome(){
  view.append(card(`Добро пожаловать!`, `Ваш личный ассистент Mellstroy.games. Начните с бонуса или примите челлендж недели.`));
  // KPIs
  const kpis = document.createElement('div'); kpis.className='row';
  kpis.append(kpi('🔥 Бонусов доступно', '3'));
  kpis.append(kpi('🎯 Челленджи активны', '2'));
  kpis.append(kpi('👥 Друзей пригласили', '12'));
  view.append(kpis);

  // Actions
  const actions = document.createElement('div'); actions.className='actions';
  actions.append(primary('Активировать бонус', ()=>navigate('bonus')));
  actions.append(primary('Принять челлендж', ()=>navigate('challenge')));
  actions.append(secondary('Открыть профиль', ()=>navigate('profile')));
  view.append(actions);

  view.append(card('Новости', null, newsList([
    'Стартовал турнир “Mell King” — призовой фонд 100 000!',
    'Новые правила кешбэка: до 20% по пятницам',
    'NFT-бейджи за streak побед — уже доступны'
  ])));
}

function renderBonus(){
  view.append(card('🎁 Мой бонус', 'Персональные предложения основаны на вашей активности.'));
  const grid = document.createElement('div'); grid.className='grid';
  grid.append(bonusTile('100% на первый депозит', 'Истекает через 2 часа', 'Актв.' ));
  grid.append(bonusTile('Кешбэк 15% сегодня', 'Только для PWA', 'Экскл.'));
  grid.append(bonusTile('Фриспины x25', 'Для новых игр', 'Новое'));
  view.append(grid);
  const row = document.createElement('div'); row.className='row';
  row.append(primary('Активировать выбранный бонус', ()=>alert('Бонус активирован (демо)')));
  row.append(secondary('Условия бонусов', ()=>alert('Показать условия (демо)')));
  view.append(row);
}

function renderChallenge(){
  view.append(card('⚡ Челлендж недели', 'Выиграй 5 игр подряд — получи NFT “Mellstroy King” 👑'));
  const ul = document.createElement('ul'); ul.className='list';
  ['Сыграть 3 матча сегодня','Пригласить друга','Одержать 2 победы подряд'].forEach((t,i)=>{
    const li = document.createElement('li');
    li.textContent = t;
    const badge = document.createElement('span'); badge.className='badge'; badge.textContent = i===0?'2/3':'0/1';
    li.append(' '); li.append(badge);
    ul.append(li);
  });
  view.append(ul);
  const row = document.createElement('div'); row.className='row';
  row.append(primary('Принять вызов', ()=>alert('Челлендж принят (демо)')));
  row.append(secondary('Правила', ()=>alert('Правила челленджа (демо)')));
  view.append(row);
}

function renderProfile(){
  view.append(card('👤 Профиль', 'Сводка по аккаунту и прогресс.'));
  const grid = document.createElement('div'); grid.className='grid';
  grid.append(kpi('Уровень', '12'));
  grid.append(kpi('Победы', '48'));
  grid.append(kpi('Стрик', '4'));
  grid.append(kpi('Баланс', '1 250'));
  view.append(grid);
  const c = document.createElement('div'); c.className='card';
  c.innerHTML = `
    <h2>Настройки</h2>
    <div class="row">
      <label class="input"><input id="nick" placeholder="Никнейм" value="@nickname"></label>
      <button class="btn" id="saveBtn">Сохранить</button>
    </div>
    <div class="row">
      <button class="btn" id="linkTelegram">Привязать Telegram</button>
      <button class="btn" id="notifications">Включить web-push</button>
    </div>
  `;
  view.append(c);
  setTimeout(()=>{
    document.getElementById('saveBtn').onclick=()=>alert('Сохранено (демо)');
    document.getElementById('linkTelegram').onclick=()=>alert('Открыть связку с ботом (демо)');
    document.getElementById('notifications').onclick=()=>alert('Запросить разрешение на уведомления (демо)');
  });
}

function card(title, subtitle=null, content=null){
  const div = document.createElement('div'); div.className='card';
  const h2 = document.createElement('h2'); h2.textContent=title; div.append(h2);
  if(subtitle){ const p = document.createElement('p'); p.textContent = subtitle; div.append(p); }
  if(content){ div.append(content); }
  return div;
}
function kpi(label, val){
  const d = document.createElement('div'); d.className='kpi';
  const p = document.createElement('div'); p.textContent=label;
  const v = document.createElement('div'); v.className='val'; v.textContent=val;
  d.append(p); d.append(v);
  return d;
}
function primary(text, onClick){ const b=document.createElement('button'); b.className='btn'; b.textContent=text; b.onclick=onClick; return b; }
function secondary(text, onClick){ const b=document.createElement('button'); b.className='btn'; b.style.background='#303a52'; b.textContent=text; b.onclick=onClick; return b; }
function bonusTile(title, note, tag){
  const d = document.createElement('div'); d.className='card';
  const h2 = document.createElement('h2'); h2.textContent=title; d.append(h2);
  const p = document.createElement('p'); p.textContent=note; d.append(p);
  const t = document.createElement('span'); t.className='tag'; t.textContent=tag; d.append(t);
  return d;
}
function newsList(items){
  const ul = document.createElement('ul'); ul.className='list';
  items.forEach(i=>{ const li=document.createElement('li'); li.textContent=i; ul.append(li); });
  return ul;
}

// --- PWA install
let deferredPrompt;
const installBtn = document.getElementById('installBtn');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installBtn.style.display='inline-flex';
});
installBtn.addEventListener('click', async () => {
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  await deferredPrompt.userChoice;
  deferredPrompt = null;
  installBtn.textContent='Установлено';
  installBtn.disabled = true;
});

// Service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js');
  });
}

// Init
navigate(location.hash.replace('#/','')||'home');
